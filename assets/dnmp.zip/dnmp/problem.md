

- jbd2/vdb-8 io



awk ‘{split($4,array,"[");if(array[2]>="05/May/2021:09:54:00" && array[2]<="05/May/2021:09:54:10"){print $0}}‘ access.log
