DNMP（Docker + Nginx + MySQL + PHP7 + Redis）是一款全功能的**LNMP一键安装程序**。

# 目录
- [目录](#目录)
  - [1.目录结构](#1目录结构)
  - [2.快速使用](#2快速使用)
  - [3.PHP和扩展](#3php和扩展)
    - [3.1 安装需要的PHP扩展](#31-安装需要的php扩展)
    - [3.2 快速安装php扩展](#32-快速安装php扩展)
    - [3.3 宿主机中使用php命令行（php-cli）](#33-宿主机中使用php命令行php-cli)
    - [3.4 使用composer（本机已有composer可忽略）](#34-使用composer本机已有composer可忽略)
  - [4.管理命令](#4管理命令)
    - [4.1 docker-compose常用命令](#41-docker-compose常用命令)
    - [4.2 添加快捷命令](#42-添加快捷命令)
  - [5.Log](#5log)
    - [5.1 Nginx日志](#51-nginx日志)
    - [5.2 PHP-FPM日志](#52-php-fpm日志)
    - [5.3 MySQL日志](#53-mysql日志)
  - [6.Nginx](#6nginx)
    - [6.1 Nginx配置](#61-nginx配置)
  - [7.php-cs代码格式化](#7php-cs代码格式化)
    - [7.1 PHPStorm-代码格式化](#71-phpstorm-代码格式化)
    - [举例](#举例)
  - [License](#license)
  - [podman](#podman)


## 1.目录结构

```
/
├── data                        数据库数据目录
│   ├── mysql                   MySQL 数据目录
├── services                    服务构建文件和配置文件目录
│   ├── mysql                   MySQL 配置文件目录
│   ├── nginx                   Nginx 配置文件目录
│   ├── php                     PHP 配置目录
│   ├── redis                   Redis 配置目录
├── logs                        日志目录
├── docker-compose.yml          Docker 服务配置文件
├── .env                        环境配置文件
└── www                         PHP 代码目录
```


## 2.快速使用
1. 本地安装
    - `git`
    - `Docker` [参考安装教程](https://vuepress.mirror.docker-practice.com/install/) (`windows用户`必须`win10`)
    - `docker-compose 1.7.0+`
    
        ```
        #推荐docker-compose国内源安装，速度较快
        $ curl -L https://get.daocloud.io/docker/compose/releases/download/1.26.2/docker-compose-`uname -s`-`uname -m` > /usr/local/bin/docker-compose
        $ chmod +x /usr/local/bin/docker-compose
        ```
2. `clone`本项目：

    ```
    $ git clone ssh://git@git.xiaoyinka.vip:2333/xiaoyinka/dnmp.git
    ```
3. 如果不是`root`用户，还需将当前用户加入`docker`用户组：

    ```
    $ sudo gpasswd -a ${USER} docker
    ```
4. 拷贝并命名配置文件（Windows系统请用`copy`命令），启动：

    ```
    $ cd dnmp                                           # 进入项目目录
    $ cp env.sample .env                                # 复制环境变量文件
    $ cp docker-compose.sample.yml docker-compose.yml   # 复制 docker-compose 配置文件
    $ docker-compose up                                 # 启动。默认启动nginx+php+mysql
    ```
5. 在浏览器中访问：`http://localhost`就能看到效果，PHP代码在文件`./www/localhost/index.php`。

## 3.PHP和扩展
### 3.1 安装需要的PHP扩展
在`.env`文件中我们仅默认安装少量扩展，
如果要安装更多扩展，请打开你的`.env`文件修改如下的PHP配置，
增加需要的PHP扩展：
```bash
PHP_EXTENSIONS=pdo_mysql,opcache,redis       # PHP 要安装的扩展列表，英文逗号隔开
```
然后重新build PHP镜像并启动。
```bash
$ docker-compose up --build php
```
### 3.2 快速安装php扩展
1.进入容器:
```sh
$ docker exec -it php /bin/sh

install-php-extensions zip
或
docker-php-ext-install zip
```

### 3.3 宿主机中使用php命令行（php-cli）

1. 在宿主机的 `~/.bashrc`文件中加入对应 php cli 函数。
    ```
    # php cli
    php () {
        tty=
        tty -s && tty=--tty
        docker run \
            $tty \
            --interactive \
            --rm \
            --volume $PWD:/www:rw \
            --workdir /www \
            dnmp_php php "$@"
    }
    ```
   其他可参考[bash.alias.sample](bash.alias.sample)示例文件，
   
2. 让文件起效：
    ```bash
    $ source ~/.bashrc
    ```
   
3. 然后就可以在主机中执行php命令了：
    ```bash
    $ php -v
    PHP 7.1.33 (cli) (built: Oct 25 2019 07:25:49) ( NTS )
    Copyright (c) 1997-2018 The PHP Group
    Zend Engine v3.1.0, Copyright (c) 1998-2018 Zend Technologies
    with Zend OPcache v7.1.33, Copyright (c) 1999-2018, by Zend Technologies
    ```

### 3.4 使用composer（本机已有composer可忽略）
**方法1：在宿主机中使用composer命令**
1. 确定composer缓存的路径。比如，我的dnmp下载在`~/dnmp`目录，那composer的缓存路径就是`~/dnmp/data/composer`。
2. 在宿主机的 `~/.bashrc`文件添加php composer 函数。

    ```bash
    composer () {
         tty=
         tty -s && tty=--tty
         docker run \
             $tty \
             --interactive \
             --rm \
             --volume ~/dnmp/data/composer:/tmp/composer \
             --workdir / \
             dnmp_php composer "$@"
    }
    ```

3. 让文件起效：

   ```bash
   $ source ~/.bashrc
   ```
   
4. 在主机的任何目录下就能用composer了：

    ```bash
    $ cd ~/dnmp/www/
    $ composer create-project --prefer-dist laravel/laravel mylaravel
    ```
   
5. （可选）第一次使用 composer 会在 `~/dnmp/data/composer` 目录下生成一个**config.json**文件，可以在这个文件中指定国内仓库，例如：
    ```json
    {
        "config": {},
        "repositories": {
            "packagist": {
                "type": "composer",
                "url": "https://php.cnpkg.org"
            }
        }
    }
    ```
   
**方法二：容器内使用composer命令**

进入PHP容器，执行`composer`命令，示例：
```bash
$ docker exec -it php /bin/sh
$ cd /www/xiaoyinka
$ composer update
```    

## 4.管理命令
### 4.1 docker-compose常用命令
```bash
$ docker-compose ps                         # ps：列出所有运行容器
$ docker-compose logs                       # logs：查看服务日志输出
$ docker-compose port nginx 80              # port：打印绑定的公共端口

$ docker-compose build php                  # build：构建或者重新构建服务
$ docker-compose start php                  # start：启动指定服务已存在的容器
$ docker-compose stop php                   # stop：停止正在运行的服务的容器
$ docker-compose rm php                     # rm：删除并停止指定服务的容器

$ docker-compose up                         # up：构建病启动所以容器
$ docker-compose up -d                      # 创建并且后台运行方式启动所有容器
$ docker-compose up nginx                   # 创建并且启动指定的nginx容器

$ docker-compose run nginx bash             # run：在一个服务上执行一个命令

$ docker-compose down                       # 停止并删除容器，网络，图像和挂载卷
```
注意：如果修改了对应的Dockerfile文件要加`--build`参数
```bash
$ docker-compose up --build php
```
### 4.2 添加快捷命令
在开发的时候，我们可能经常使用`docker exec -it 容器名 `进入到某容器中，把常用的做成命令别名是个省事的方法。

首先，在宿主机中查看可用的容器：
```bash
$ docker ps           # 查看所有运行中的容器
$ docker ps -a        # 所有容器
```
输出的`NAMES`那一列就是容器的名称，如果使用默认配置，那么名称就是`nginx`、`php`、`mysql`等。

然后，打开宿主机的`~/.bashrc`文件，加上：
```bash
alias dnginx='docker exec -it nginx /bin/sh'
alias dphp='docker exec -it php /bin/sh'
alias dmysql='docker exec -it mysql /bin/bash'
alias dredis='docker exec -it redis /bin/sh'
```
让命令生效
```bash
$ source ~/.bashrc
```
下次进入容器就非常快捷了，如进入php容器：
```bash
$ dphp
```

## 5.Log

Log文件生成的位置依赖于conf下各log配置的值。

### 5.1 Nginx日志
Nginx日志是我们用得最多的日志，所以我们单独放在根目录`log`下。

`log`会目录映射Nginx容器的`/var/log/nginx`目录，所以在Nginx配置文件中，需要输出log的位置，我们需要配置到`/var/log/nginx`目录，如：
```
error_log  /var/log/nginx/nginx.localhost.error.log  warn;
```


### 5.2 PHP-FPM日志
大部分情况下，PHP-FPM的日志都会输出到Nginx的日志中，所以不需要额外配置。

另外，建议直接在PHP中打开错误日志：
```php
error_reporting(E_ALL);
ini_set('error_reporting', 'on');
ini_set('display_errors', 'on');
```

如果确实需要，可按如下步骤开启（在容器中）。

1. 进入容器，创建日志文件并修改权限：

    ```bash
    $ docker exec -it php /bin/sh
    $ mkdir /var/log/php
    $ cd /var/log/php
    $ touch php-fpm.error.log
    $ chmod a+w php-fpm.error.log
    ```
   
2. 主机上打开并修改PHP-FPM的配置文件`conf/php-fpm.conf`，找到如下一行，删除注释，并改值为：

    ```
    php_admin_value[error_log] = /var/log/php/php-fpm.error.log
    ```
   
3. 重启PHP-FPM容器。

### 5.3 MySQL日志
因为MySQL容器中的MySQL使用的是`mysql`用户启动，它无法自行在`/var/log`下的增加日志文件。所以，我们把MySQL的日志放在与data一样的目录，即项目的`mysql`目录下，对应容器中的`/var/lib/mysql/`目录。

```bash
slow-query-log-file     = /var/lib/mysql/mysql.slow.log
log-error               = /var/lib/mysql/mysql.error.log
```
以上是mysql.conf中的日志文件的配置。

## 6.Nginx
### 6.1 Nginx配置
1.端口。默认的是`80`，可以通过修改docker-compose.yml中nginx的ports自行配置,实例：
```
......
    ports:
      - "80:80"
      - "8080:8080"     
......
```
2.虚拟主机配置。在dnmp项目services/nginx/conf.d/下添加配置，参考`test.conf.sample`：
```
server {
    listen       8080;
    server_name  127.0.0.1;
    root   /www/xiaoyinka/public;
    index  index.php index.html index.htm;

    location / {
        if (!-e $request_filename) {
        rewrite  ^(.*)$  /index.php?s=/$1  last;
        break;
        }
    }
    
    access_log  /var/log/nginx/nginx.web.xiaoyinka.test.access.log  main;
    error_log  /var/log/nginx/nginx.web.xiaoyinka.test.error.log  warn;
    
    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    error_page   500 502 503 504  /50x.html;
    location = /50x.html {
        root   /usr/share/nginx/html;
    }

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1:8080;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    location ~ \.php$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        fastcgi_pass   php:9000;
        include        fastcgi-php.conf;
        include        fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}
    
```

访问`127.0.0.1:8080`，完成。

## 7.php-cs代码格式化

### 7.1 PHPStorm-代码格式化
`docker exec -it php /bin/sh`进入php容器，composer全局安装`phpcs`代码检测工具和`php-cs-fixer`代码修复工具

```bash
#phpcs
composer global require 'squizlabs/php_codesniffer=*'

#php-cs-fixer
composer global require friendsofphp/php-cs-fixer
```

1. PHPStorm中配置
    - `php`
    
        1）PHPStorm选择 `File`->`Setting`->`Languages & Frameworks`->`PHP`
        
        2）`CLI Interpreter` 配置为`docker`服务中php容器的环境
    - `php-cs`
        
        1）PHPStorm选择 `File`->`Setting`->`Languages & Frameworks`->`PHP`->`Quality Tools`->`PHP_CodeSniffer`,
        
        2）点击`Configuration`右侧按钮，选择`PHP_CodeSniffer path:`的路径（此处为php-cs的可执行文件地址，切记用`全路径`，地址其实就是php容器中composer对应`宿主机的地址`）
        
        3）点击`Validate`验证是否可用
        
        ![alt 如下图](https://img-blog.csdnimg.cn/20200820140033993.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzI4OTMzODAz,size_16,color_FFFFFF,t_70#pic_center)
        
        4）选择`File`->`Setting`->`Editor`->`Inspections`展开点击`PHP`找到`Quality tools`
        
        5）找到`PHP CodeSniffer Validation` 勾上`✔`，`Coding standard` 选择`PSR2`，应用即可
        
        ![alt 如下图](https://img-blog.csdnimg.cn/20200820135913724.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzI4OTMzODAz,size_16,color_FFFFFF,t_70#pic_center)

    - `php-cs-fix`
    
        PHPStorm选择 `File`->`Setting`->`Tools`->`External Tools`->`+`，如下
     
        ![alt 如下图](https://www.pianshen.com/images/318/d748eb9649dacd9c06513dc644563196.png)
    
        说明：
    
        `Program` 填`/dnmp/data/composer/vendor/bin/php-cs-fixer`（此处为php-cs-fixer的可执行文件地址，切记用`全路径`，地址其实就是php容器中composer对应`宿主机的地址`）
    
        `Arguments/parameters`填`fix "$FileDir$/$FileName$" --rules=@PSR2 --allow-risky=yes `，其中` rules `字段具体可以查看 php-cs-fixer 的官方文档，此处设为psr2
    
        `Working directory`填`$ProjectFileDir$`
    
2. 使用
   
   在项目php代码文件`右键`->`External Tools`，点击选择你命名的`php-cs-fixer`，即可进行代码格式化
***
### 举例
部署xiaoyinka/xiaoyinka项目并运行

1、克隆项目远程代码

```bash
# 由于已经做了宿主机的目录映射，可直接在宿主机的www目录下克隆
# 或
# 执行`docker exec -it php /bin/sh` 进入php容器后到/www目录下克隆

#克隆（记得将ssh密钥加入远程仓库配置）
git clone ssh://git@git.xiaoyinka.vip:2333/xiaoyinka/xiaoyinka.git

# 进入xiaoyinka项目目录，composer
composer install

# 初始化init，选择[0]:dev模式，生成.env文件
php init

```

2、配置nginx

参考`/services/nginx/conf.d/test.conf.sample`

3、访问`127.0.0.1:8080`即可


## License
MIT


## podman

```
podman run --name=nginx -d -e TZ=Asia/Shanghai -v /Users/sanehe/xiaoyinka/:/www/:rw -v /Users/sanehe/xiaoyinka/dnmp/./services/nginx/conf.d:/etc/nginx/conf.d/:rw -v /Users/sanehe/xiaoyinka/dnmp/./services/nginx/nginx.conf:/etc/nginx/nginx.conf:ro -v /Users/sanehe/xiaoyinka/dnmp/./services/nginx/fastcgi-php.conf:/etc/nginx/fastcgi-php.conf:ro -v /Users/sanehe/xiaoyinka/dnmp/./services/nginx/fastcgi_params:/etc/nginx/fastcgi_params:ro -v /Users/sanehe/xiaoyinka/dnmp/./logs/nginx:/var/log/nginx/:rw --add-host nginx:192.168.64.7 --add-host php:192.168.64.7 --expose 80 -p 8080:80 dnmp_nginx


podman run --name=php -d -v /Users/sanehe/xiaoyinka/:/www/:rw -v /Users/sanehe/xiaoyinka/dnmp/./services/php/php.ini:/usr/local/etc/php/php.ini:ro -v /Users/sanehe/xiaoyinka/dnmp/./services/php/php-fpm.conf:/usr/local/etc/php-fpm.d/www.conf:rw -v /Users/sanehe/xiaoyinka/dnmp/./logs/php:/var/log/php -v /Users/sanehe/xiaoyinka/dnmp/./data/composer:/tmp/composer --add-host nginx:192.168.64.7 --add-host php:192.168.64.7 --expose 9000 --expose 9002 -p 9000:9000 -p 9002:9002 dnmp_php
```
