# Kubernetes quick starts
## Hosting 
国内Gitlab: https://gitlab.abcxlab.com/bootcamp/k8s-quick-start  
国外Github：https://github.com/abcxlab/k8s-quick-start  
## Directory 
/app -- for demo applicatons, includes kubia in nodejs and micro in springboot  
/k8s -- for kubernetes cluster deployment   
/etcd -- for etcd cluster installation and use case   
/helm -- for helm and kubeapps deployment and use cases   

## Demo Env
demo address:  https://k8s.abcxlab.com/

login token: 请扫码关注ABC实验室微信公众号，输入”k8s” 即可获取  
![ABC实验室](https://www.abcxlab.com/wp-content/uploads/2020/03/qrcode_abcxlab.jpg)

## Installation Guide 
https://www.abcxlab.com/research/cloud/202005072134085267.html
